var mainanswers = new Array();
var useranswers = new Array();
var answered = 0;
var Score;
var ScoreMessage;
var isNetscape = (navigator.appName=="Netscape");

if(typeof(SD)=='undefined' || SD == null)
{
	SD = window.parent //should be indexAPI.html
}

function renderQuiz()
{
	for(i = 0; i < questions.length; i ++ )
	{
		useranswers[i] = new Array();
		document.writeln('<p class="question">' + questions[i] + ' <span id="result_' + i + '"></span></p>');
		if(type[i] == "MultiChoiceSingleSelect")
		{
			for(j = 0; j < choices[i].length; j ++ )
			{
				useranswers[i][j]=false;
				document.writeln('<input type="radio" name="answer_' + i + '" value="' + choices[i][j] + '" id="answer_' + i + '_' + j + '" class="question_' + i + '" onclick="submitAnswer(' + i + ', ' + j + ', this, \'question_' + i + '\', \'label_' + i + '_' + j + '\')" /><label id="label_' + i + '_' + j + '" for="answer_' + i + '_' + j + '"> ' + choices[i][j] + '</label><br />');
			}
		}
		else
		{
			if(type[i] == "MultiChoiceMultiSelect")
			{
				for(j = 0; j < choices[i].length; j ++ )
				{
					useranswers[i][j]=false;
					document.writeln('<input type="checkbox" name="answer_' + i + '" value="' + choices[i][j] + '" id="answer_' + i + '_' + j + '" class="question_' + i + '" onclick="submitAnswer(' + i + ', ' + j + ', this, \'question_' + i + '\', \'label_' + i + '_' + j + '\')" /><label id="label_' + i + '_' + j + '" for="answer_' + i + '_' + j + '"> ' + choices[i][j] + '</label><br />');
				}
			}
		}
	}
	document.writeln('<p><input type="submit" value="Submit" onclick="showScore()" /></p><p style="display:none"></p>');
}
function keypress()
{
	alert("keypress event detected!");
}

function BackSpaceClose()
{
	/* var key_pressed = event.keyCode; */
	if(event.keyCode == 8)
	{
	//	window.close();  
	 	if(isNetscape)
			netscape.security.PrivilegeManager.enablePrivilege("UniversalBrowserWrite");
			
		window.close();
	} 
 	/* netscape.security.PrivilegeManager.enablePrivilege("UniversalBrowserWrite");
 	CloseDoc(); */
}

function which_key()
{
	var key_pressed = event.keyCode;
	alert(key_pressed);
	CloseDoc();
}

function CloseDoc() 
{
	/*netscape.security.PrivilegeManager.enablePrivilege("UniversalBrowserWrite");*/
	/* window.open('','_self'); */
	//doLMSFinish();
	SD.ConcedeControl();
	
	if(isNetscape)
		netscape.security.PrivilegeManager.enablePrivilege("UniversalBrowserWrite");
	
	window.close();
}
function resetQuiz(showConfirm)
{
	if(showConfirm)
	{
		if(!confirm("Are you sure you want to reset your answers and start from the beginning?"))
			return false;
		document.location = document.location;
		element.location = element.location;
	}
}

function submitAnswer(questionId, answerId, obj, classId, labelId)
{
	if(type[questionId] == "MultiChoiceSingleSelect")
	{
		for ( j = 0; j < useranswers[questionId].length; j ++ )
			useranswers[questionId][j] = false;
		
		useranswers[questionId][answerId] = true;
	}
	else
	{
		if(useranswers[questionId][answerId] == true)
			useranswers[questionId][answerId] = false;
		else if(useranswers[questionId][answerId] == false)
			useranswers[questionId][answerId] = true;
	}
	answered ++ ;
}

function showResult(questionId)
{
	if(answers[questionId] == useranswers[questionId])
		$('#result_' + questionId).html('<img src="correct.gif" style="border:0" alt="Correct!" />');
	else
		$('#result_' + questionId).html('<img src="incorrect.gif" style="border:0" alt="Incorrect!" />');
}

function showScore()
{    
	var strResult = "";
	var TotalQuestions = 0;
	var totalCorrect = 0;
	var isCorrect = true;
   
	for(i = 0; i < questions.length; i++)
	{
		TotalQuestions++;
		isCorrect = true;
		for(j = 0; j < useranswers[i].length; j++)
		{
			if(answers[i][j] != useranswers[i][j] )
			{
				isCorrect = false;
				break;
			}
		}
		if(isCorrect == true)
			totalCorrect++;
	}

	var Result = Math.round((totalCorrect * 100) / TotalQuestions);                           
	var assessmentScore = Result;
	
	/*
	var coreItems = doLMSGetValue("cmi.core.score._children");
	if ((coreItems.indexOf("raw")) != -1) 
	{
		doLMSSetValue("cmi.core.score.raw", assessmentScore);
	}
	else 
	{
		alert("LMS is not SCORM Complaint. It does not support cmi.core.score.raw.");
	}
	
	
	var maxScore = false;
	if ((coreItems.indexOf("max") != -1) && (coreItems.indexOf("min") != -1)) 
	{
		doLMSSetValue("cmi.core.score.min", "0");
		doLMSSetValue("cmi.core.score.max", "100");
		maxScore = true;
   	}
	else 
	{
		alert("LMS is not SCORM Complaint. It does not support cmi.core.score.max or cmi.core.score.min.");
	}
	*/
	
	blnResult = SD.SetScore(assessmentScore,100,0);
	
	
	$('#divquestionHide').hide();
	$('#divdisplayscore').show();

	if (assessmentScore >= 80) 
	{
		//doLMSSetValue("cmi.core.lesson_status", "passed");
		blnResult = SD.SetPassed();
		$('#spanscore').html('Congratulations, you have passed this course!<br/>Your score is: ' + assessmentScore);
	}
	else 
	{
		//doLMSSetValue("cmi.core.lesson_status", "incomplete"); 
		blnResult = SD.ResetStatus();
		$('#spanscore').html('You have not achieved a passing score for this quiz.<br/>Your score is: ' + assessmentScore);
	}
	blnresult = SD.CommitData();
}

function CloseTestWindow(btn) {
	//doLMSFinish();
	SD.ConcedeControl();
	btn.disabled = 1;
	if (window.parent) 
		window.parent.close();
	else 
		window.close();
}
	
function YourScore()
{
	//Score = LMSGetValue("cmi.core.score.raw");
	Score = SD.GetScore();
	return Score;
}
function ScorMessage()
{
	return ScoreMessage;
}

function disableQuestion(classId)
{
	var alltags = document.all ? document.all : document.getElementsByTagName("*")
	for (i = 0; i < alltags.length; i ++ )
	{
		if (alltags[i].className == classId)
		{
			alltags[i].disabled = true;
		}
	}
}
