 function CourseCompleted(CourseName) {
     SD.SetBookmark("exam");
     if (typeof (questions) != "undefined") {
         if (questions.length > 0) {
			$('#view-exam').fadeIn();
         }
     }
	else
	{
		SD.SetReachedEnd();
		alert('You have successfully completed this course.');
		SD.CommitData();
	}
 }