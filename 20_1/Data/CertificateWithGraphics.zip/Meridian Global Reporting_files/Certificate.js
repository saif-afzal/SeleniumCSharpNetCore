//Set up member variables that are passed through Querystring and can be used through
//rest of certificate

var m_strUsedId	= "";
var m_strContentId	= "";
var m_strLocaleId	= "";
var m_strDomainId	= "";
var m_strAttemptId 	= "";

var args = new Object();
var strQueryString = location.search.substring(1);
var arrPairs = strQueryString.split("&");

var m_strGlobalParams = "";
var m_strParams = "";

for (var i=0;i<arrPairs.length;i++) 
{
	var arrValuePair;
	switch (i)
	{	
		case 0:
			arrValuePair = arrPairs[i].split("=");
			m_strUserId = arrValuePair[1];
			break;
			
		case 1:
			arrValuePair = arrPairs[i].split("=");
			m_strContentId = arrValuePair[1];
			break;
			
		case 2:
			arrValuePair = arrPairs[i].split("=");
			m_strLocaleId = arrValuePair[1];
			break;
			
		case 3:
			arrValuePair = arrPairs[i].split("=");
			m_strDomainId = arrValuePair[1];
			break;

		case 4:
			arrValuePair = arrPairs[i].split("=");
			m_strAttemptId = arrValuePair[1];
			break;
		
		default:
			break;	
	}
}

m_strGlobalParams = "strUserId=" + m_strUserId + "&strDomainId=" + m_strDomainId + "&strLocaleId=" + m_strLocaleId + "&strContentId=" + m_strContentId + "&strAttemptId=" + m_strAttemptId;

RunTestCalls();

function RunTestCalls()
{
	//alert ('GetCourseStartDate: ' + GetGenericValue ("GetCourseStartDate") + '\nGetCourseScore: ' + GetGenericValue("GetCourseScore"));
}

function CreateXMLHTTPRequest () 
{
	try { return new ActiveXObject("Msxml2.XMLHTTP"); } catch (e) {}
	try { return new ActiveXObject("Microsoft.XMLHTTP"); } catch (e) {}
	try { return new XMLHttpRequest(); } catch(e) {}
	alert("XMLHttpRequest not supported");
	return null;
}

function GetGenericValue (strRequestedValue)
{
	var strReturnValue = "";
	switch (strRequestedValue)
	{
		case "GetUserName":
			strReturnValue = GetUserName();
			break;

		case "GetUserFirstName":
			strReturnValue = GetUserFirstName();			
			break;
			
		case "GetUserLastName":
			strReturnValue = GetUserLastName();
			break;			

		case "GetUserMiddleName":
			strReturnValue = GetUserMiddleName();
			break;
			
		case "GetContentName":
			strReturnValue = GetContentName();
			break;

		case "GetUserPositionName":
			strReturnValue = GetUserPositionName();
			break;

		case "GetCourseStartDate":
			strReturnValue = GetCourseStartDate();
			break;

		case "GetCourseCompletionDate":
			strReturnValue = GetCourseCompletionDate();
			break;

		case "GetManagerFullName":
			strReturnValue = GetManagerFullName();
			break;

		case "GetUserOrganization":
			strReturnValue = GetUserOrganization();
			break;
			
		case "GetUserJobTitle":
			strReturnValue = GetUserJobTitle();
			break;
			
		case "GetCurrentDomainTitle":
			strReturnValue = GetCurrentDomainTitle();
			break;
			
		case "GetContentType":
			strReturnValue = GetContentType();
			break;
			
		case "GetCourseProvider":
			strReturnValue = GetCourseProvider();
			break;

		case "GetCourseCEUs":
			strReturnValue = GetCourseCEUs();
			break;

		case "GetCreditType":
			strReturnValue = GetCreditType();
			break;
			
		case "GetDefinedCourseDuration":
			strReturnValue = GetDefinedCourseDuration();
			break;
			
		case "GetCourseScore":
			strReturnValue = GetCourseScore();
			break;
			
		default:
			break;
	}
	return strReturnValue;	
}

function GetCourseScore()
{
	var objXMLHTTPRequest = CreateXMLHTTPRequest();
	objXMLHTTPRequest.open ("POST", "/KView/CustomCodeBehind/Base/Utilities/CertificateLibraryCalls.aspx", false);
	objXMLHTTPRequest.setRequestHeader ("Content-type", "application/x-www-form-urlencoded");
	m_strParams = "strCall=GetCourseScore&" + m_strGlobalParams;
	objXMLHTTPRequest.send (m_strParams);

	var strReturnValue = objXMLHTTPRequest.responseText;
	if (strReturnValue == "")
	{
		strReturnValue = "{CourseProvider}";
	}
	
 	return strReturnValue;

}

function GetCourseProvider()
{
	var objXMLHTTPRequest = CreateXMLHTTPRequest();
	objXMLHTTPRequest.open ("POST", "/KView/CustomCodeBehind/Base/Utilities/CertificateLibraryCalls.aspx", false);
	objXMLHTTPRequest.setRequestHeader ("Content-type", "application/x-www-form-urlencoded");
	m_strParams = "strCall=GetCourseProvider&" + m_strGlobalParams;
	objXMLHTTPRequest.send (m_strParams);

	var strReturnValue = objXMLHTTPRequest.responseText;
	if (strReturnValue == "")
	{
		strReturnValue = "{CourseProvider}";
	}
	
 	return strReturnValue;
}

function GetCreditType()
{
	var objXMLHTTPRequest = CreateXMLHTTPRequest();
	objXMLHTTPRequest.open ("POST", "/KView/CustomCodeBehind/Base/Utilities/CertificateLibraryCalls.aspx", false);
	objXMLHTTPRequest.setRequestHeader ("Content-type", "application/x-www-form-urlencoded");
	m_strParams = "strCall=GetCreditType&" + m_strGlobalParams;
	objXMLHTTPRequest.send (m_strParams);

	var strReturnValue = objXMLHTTPRequest.responseText;
	if (strReturnValue == "")
	{
		strReturnValue = "{CreditType}";
	}
	
 	return strReturnValue;
}

function GetDefinedCourseDuration()
{
	var objXMLHTTPRequest = CreateXMLHTTPRequest();
	objXMLHTTPRequest.open ("POST", "/KView/CustomCodeBehind/Base/Utilities/CertificateLibraryCalls.aspx", false);
	objXMLHTTPRequest.setRequestHeader ("Content-type", "application/x-www-form-urlencoded");
	m_strParams = "strCall=GetDefinedCourseDuration&" + m_strGlobalParams;
	objXMLHTTPRequest.send (m_strParams);

	var strReturnValue = objXMLHTTPRequest.responseText;
	if (strReturnValue == "")
	{
		strReturnValue = "{CourseDefinedDuration}";
	}
	
 	return strReturnValue;
}

function GetContentType()
{
	var objXMLHTTPRequest = CreateXMLHTTPRequest();
	objXMLHTTPRequest.open ("POST", "/KView/CustomCodeBehind/Base/Utilities/CertificateLibraryCalls.aspx", false);
	objXMLHTTPRequest.setRequestHeader ("Content-type", "application/x-www-form-urlencoded");
	m_strParams = "strCall=GetContentType&" + m_strGlobalParams;
	objXMLHTTPRequest.send (m_strParams);

	var strReturnValue = objXMLHTTPRequest.responseText;
	if (strReturnValue == "")
	{
		strReturnValue = "{ContentType}";
	}
	
 	return strReturnValue;
}

function GetCurrentDomainTitle()
{
	var objXMLHTTPRequest = CreateXMLHTTPRequest();
	objXMLHTTPRequest.open ("POST", "/KView/CustomCodeBehind/Base/Utilities/CertificateLibraryCalls.aspx", false);
	objXMLHTTPRequest.setRequestHeader ("Content-type", "application/x-www-form-urlencoded");
	m_strParams = "strCall=GetCurrentDomainTitle&" + m_strGlobalParams;
	objXMLHTTPRequest.send (m_strParams);

	var strReturnValue = objXMLHTTPRequest.responseText;
	if (strReturnValue == "")
	{
		strReturnValue = "{CurrentDomainTitle}";
	}
	
	return strReturnValue;
}

function GetUserJobTitle()
{
	var objXMLHTTPRequest = CreateXMLHTTPRequest();
	objXMLHTTPRequest.open ("POST", "/KView/CustomCodeBehind/Base/Utilities/CertificateLibraryCalls.aspx", false);
	objXMLHTTPRequest.setRequestHeader ("Content-type", "application/x-www-form-urlencoded");
	m_strParams = "strCall=GetUserJobTitle&" + m_strGlobalParams;
	objXMLHTTPRequest.send (m_strParams);

	var strReturnValue = objXMLHTTPRequest.responseText;
	if (strReturnValue == "")
	{
		strReturnValue = "{UserJobTitle}";
	}
	
	return strReturnValue;
}

function GetUserOrganization()
{
	var objXMLHTTPRequest = CreateXMLHTTPRequest();
	objXMLHTTPRequest.open ("POST", "/KView/CustomCodeBehind/Base/Utilities/CertificateLibraryCalls.aspx", false);
	objXMLHTTPRequest.setRequestHeader ("Content-type", "application/x-www-form-urlencoded");
	m_strParams = "strCall=GetUserOrganization&" + m_strGlobalParams;
	objXMLHTTPRequest.send (m_strParams);

	var strReturnValue = objXMLHTTPRequest.responseText;
	if (strReturnValue == "")
	{
		strReturnValue = "{UserOrganization}";
	}
	
	return strReturnValue;
}

function GetManagerFullName()
{
	var objXMLHTTPRequest = CreateXMLHTTPRequest();
	objXMLHTTPRequest.open ("POST", "/KView/CustomCodeBehind/Base/Utilities/CertificateLibraryCalls.aspx", false);
	objXMLHTTPRequest.setRequestHeader ("Content-type", "application/x-www-form-urlencoded");
	m_strParams = "strCall=GetManagerFullName&" + m_strGlobalParams;
	objXMLHTTPRequest.send (m_strParams);

	var strReturnValue = objXMLHTTPRequest.responseText;
	if (strReturnValue == "")
	{
		strReturnValue = "{ManagerFullName}";
	}
	
	return strReturnValue;
}

function GetUserFirstName()
{
	var objXMLHTTPRequest = CreateXMLHTTPRequest();
	objXMLHTTPRequest.open ("POST", "/KView/CustomCodeBehind/Base/Utilities/CertificateLibraryCalls.aspx", false);
	objXMLHTTPRequest.setRequestHeader ("Content-type", "application/x-www-form-urlencoded");
	m_strParams = "strCall=GetUserFirstName&" + m_strGlobalParams;
	objXMLHTTPRequest.send (m_strParams);

	var strReturnValue = objXMLHTTPRequest.responseText;
	if (strReturnValue == "")
	{
		strReturnValue = "{UserFirstName}";
	}
	
	return strReturnValue;
}

function GetUserLastName()
{
	var objXMLHTTPRequest = CreateXMLHTTPRequest();
	objXMLHTTPRequest.open ("POST", "/KView/CustomCodeBehind/Base/Utilities/CertificateLibraryCalls.aspx", false);
	objXMLHTTPRequest.setRequestHeader ("Content-type", "application/x-www-form-urlencoded");
	m_strParams = "strCall=GetUserLastName&" + m_strGlobalParams;
	objXMLHTTPRequest.send (m_strParams);

	var strReturnValue = objXMLHTTPRequest.responseText;
	if (strReturnValue == "")
	{
		strReturnValue = "{UserLastName}";
	}
	
	return strReturnValue;
}

function GetUserMiddleName()
{
	var objXMLHTTPRequest = CreateXMLHTTPRequest();
	objXMLHTTPRequest.open ("POST", "/KView/CustomCodeBehind/Base/Utilities/CertificateLibraryCalls.aspx", false);
	objXMLHTTPRequest.setRequestHeader ("Content-type", "application/x-www-form-urlencoded");
	m_strParams = "strCall=GetUserMiddleName&" + m_strGlobalParams;
	objXMLHTTPRequest.send (m_strParams);

	var strReturnValue = objXMLHTTPRequest.responseText;
	if (strReturnValue == "")
	{
		strReturnValue = "{UserMiddleName}";
	}
			
	return strReturnValue
}

function GetContentName()
{
	var objXMLHTTPRequest = CreateXMLHTTPRequest();
	objXMLHTTPRequest.open ("POST", "/KView/CustomCodeBehind/Base/Utilities/CertificateLibraryCalls.aspx", false);
	objXMLHTTPRequest.setRequestHeader ("Content-type", "application/x-www-form-urlencoded");
	m_strParams = "strCall=GetContentName&" + m_strGlobalParams;
	objXMLHTTPRequest.send (m_strParams);

	var strReturnValue = objXMLHTTPRequest.responseText;
	
	if (strReturnValue == "")
	{
		strReturnValue = "{CourseName}";
	}
	
 	return strReturnValue;
}

function GetUserPositionName()
{
	var objXMLHTTPRequest = CreateXMLHTTPRequest();
	objXMLHTTPRequest.open ("POST", "/KView/CustomCodeBehind/Base/Utilities/CertificateLibraryCalls.aspx", false);
	objXMLHTTPRequest.setRequestHeader ("Content-type", "application/x-www-form-urlencoded");
	m_strParams = "strCall=GetUserPositionName&" + m_strGlobalParams;
	objXMLHTTPRequest.send (m_strParams);

	var strReturnValue = objXMLHTTPRequest.responseText;
	if (strReturnValue == "")
	{
		strReturnValue = "{UserPositionName}";
	}
	return strReturnValue;			
}

function GetCourseStartDate()
{
	var objXMLHTTPRequest = CreateXMLHTTPRequest();
	objXMLHTTPRequest.open ("POST", "/KView/CustomCodeBehind/Base/Utilities/CertificateLibraryCalls.aspx", false);
	objXMLHTTPRequest.setRequestHeader ("Content-type", "application/x-www-form-urlencoded");
	m_strParams = "strCall=GetCourseStartDate&" + m_strGlobalParams;
	objXMLHTTPRequest.send (m_strParams);

	var strReturnValue = objXMLHTTPRequest.responseText;
	if (strReturnValue == "")
	{
		strReturnValue = "{StartDate}";
	}
	return strReturnValue
}

function GetCourseCompletionDate()
{
	var objXMLHTTPRequest = CreateXMLHTTPRequest();
	objXMLHTTPRequest.open ("POST", "/KView/CustomCodeBehind/Base/Utilities/CertificateLibraryCalls.aspx", false);
	objXMLHTTPRequest.setRequestHeader ("Content-type", "application/x-www-form-urlencoded");
	m_strParams = "strCall=GetCourseCompletionDate&" + m_strGlobalParams;
	objXMLHTTPRequest.send (m_strParams);

	var strReturnValue = objXMLHTTPRequest.responseText;
	if (strReturnValue == "")
	{
		strReturnValue = "{CompletionDate}";
	}
	return strReturnValue
}

function GetCourseCEUs()
{
	var objXMLHTTPRequest = CreateXMLHTTPRequest();
	objXMLHTTPRequest.open ("POST", "/KView/CustomCodeBehind/Base/Utilities/CertificateLibraryCalls.aspx", false);
	objXMLHTTPRequest.setRequestHeader ("Content-type", "application/x-www-form-urlencoded");
	m_strParams = "strCall=GetCourseCEUs&" + m_strGlobalParams;
	objXMLHTTPRequest.send (m_strParams);

	var strReturnValue = objXMLHTTPRequest.responseText;
	if (strReturnValue == "")
	{
		strReturnValue = "{CourseCEUs}";
	}

	return strReturnValue;			
}

function GetUserName()
{
	var objXMLHTTPRequest = CreateXMLHTTPRequest();
	objXMLHTTPRequest.open ("POST", "/KView/CustomCodeBehind/Base/Utilities/CertificateLibraryCalls.aspx", false);
	objXMLHTTPRequest.setRequestHeader ("Content-type", "application/x-www-form-urlencoded");
	m_strParams = "strCall=GetUserName&" + m_strGlobalParams;
	objXMLHTTPRequest.send (m_strParams);

	var strReturnValue = objXMLHTTPRequest.responseText;
	if (strReturnValue == "")
	{
	        strReturnValue = "{FullUserName}";
	}

	return strReturnValue;
}


function MM_setTextOfLayer(objId,x,newText) { //v9.0
        with (document) if (getElementById && ((obj=getElementById(objId))!=null))
   	     with (obj) innerHTML = unescape(newText);
}